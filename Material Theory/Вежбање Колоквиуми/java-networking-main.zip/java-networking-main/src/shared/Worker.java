package shared;

import java.io.*;
import java.net.Socket;
import java.util.Random;

public class Worker extends Thread{

    private Socket socket;
    private File logFile;
    private File clientsCountFile;

    public Worker(Socket socket, File logFile, File clientsCountFile) {
        this.socket = socket;
        this.logFile = logFile;
        this.clientsCountFile = clientsCountFile;
    }

    @Override
    public void run() {
        BufferedWriter writer = null;
        BufferedReader socketReader = null;
        RandomAccessFile clientCounterRaf = null;
        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.logFile)));
            socketReader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            clientCounterRaf = new RandomAccessFile(this.clientsCountFile, "rw");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Integer currentClientsCounter = null;
        try {
            currentClientsCounter = clientCounterRaf.readInt();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (currentClientsCounter == null) {
            currentClientsCounter = 0;
        }
        String line = null;
        try {
            while ((line = socketReader.readLine())!=null) {
                writer.append(line + "\n");
            }
            currentClientsCounter++;
            clientCounterRaf.seek(0);
            clientCounterRaf.writeInt(currentClientsCounter);
            System.out.printf("Total Number of Clients until now: %d.\n",currentClientsCounter);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                writer.flush();
                writer.close();
                socketReader.close();
                clientCounterRaf.close();
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}
